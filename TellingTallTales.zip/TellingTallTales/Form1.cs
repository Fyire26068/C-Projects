﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TellingTallTales
{
    public partial class TallTale : Form
    {
        public TallTale()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void storyButton_Click(object sender, EventArgs e)
        {
            FinalStoryText.Text = "";
            string myStoryText = "Once upon a time, there was a ";
            myStoryText += speciesComboBox.Text;
            myStoryText += " named";
            myStoryText += nameTxtBox.Text;
            myStoryText += " This creature was always ";
            myStoryText += ActivityList.SelectedItem;
            
            if(checkBox1.Checked = true)
            {
                myStoryText += " and";
                myStoryText += checkBox1.Text;
            }
            if(checkBox2.Checked = true)
            {
                myStoryText += " and";
                myStoryText += checkBox2.Text;
            }
            if (checkBox3.Checked = true)
            {
                myStoryText += " and";
                myStoryText += checkBox2.Text;
            }
            myStoryText += " One day this creaure saw a ";
            if(radioButton1.Checked = true)
            {
                myStoryText += radioButton1.Text;
            }
            else if(radioButton2.Checked = true)
            {
                myStoryText += radioButton2.Text;
            }
            else if(radioButton3.Checked = true)
            {
                myStoryText += radioButton3.Text;
            }
            myStoryText += " This was a ";
            myStoryText += GoodBadList.SelectedItem;
            myStoryText += " day.";

            FinalStoryText.Text = myStoryText;

        }
    }
}
