﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter4Activity
{
    public partial class DataTypes : Form
    {
        public DataTypes()
        {
            InitializeComponent();
        }

        private void numBttn_Click(object sender, EventArgs e)
        {
            int myInt = 1;
            double myDouble = 1;
            decimal myDecimal = 1;
            float myFloat = 1;
            MessageBox.Show("Int : " + myInt.ToString());
            MessageBox.Show("Double : " + myDouble.ToString());
            MessageBox.Show("Decimal : " + myDecimal.ToString());
            MessageBox.Show("Float : " + myFloat.ToString());
        }

        private void conBttn_Click(object sender, EventArgs e)
        {
            double pi = 3.14159;
            int x = 1;
            MessageBox.Show("Pi : "+ pi.ToString());
            MessageBox.Show("x : " + x.ToString());
        }

        private void boolBttn_Click(object sender, EventArgs e)
        {
            bool myBool = true;
            MessageBox.Show("Bool : " + myBool.ToString());
        }

        private void strBttn_Click(object sender, EventArgs e)
        {
            char myChar = 'f';
            string myString = "One";
            MessageBox.Show("Char : " + myChar.ToString());
            MessageBox.Show("String : " + myString);
        }
    }
}
