﻿namespace Chapter4Activity
{
    partial class DataTypes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numBttn = new System.Windows.Forms.Button();
            this.boolBttn = new System.Windows.Forms.Button();
            this.conBttn = new System.Windows.Forms.Button();
            this.strBttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // numBttn
            // 
            this.numBttn.Location = new System.Drawing.Point(164, 86);
            this.numBttn.Name = "numBttn";
            this.numBttn.Size = new System.Drawing.Size(185, 42);
            this.numBttn.TabIndex = 0;
            this.numBttn.Text = "Numeric Data";
            this.numBttn.UseVisualStyleBackColor = true;
            this.numBttn.Click += new System.EventHandler(this.numBttn_Click);
            // 
            // boolBttn
            // 
            this.boolBttn.Location = new System.Drawing.Point(164, 149);
            this.boolBttn.Name = "boolBttn";
            this.boolBttn.Size = new System.Drawing.Size(185, 44);
            this.boolBttn.TabIndex = 1;
            this.boolBttn.Text = "Bool Data";
            this.boolBttn.UseVisualStyleBackColor = true;
            this.boolBttn.Click += new System.EventHandler(this.boolBttn_Click);
            // 
            // conBttn
            // 
            this.conBttn.Location = new System.Drawing.Point(164, 215);
            this.conBttn.Name = "conBttn";
            this.conBttn.Size = new System.Drawing.Size(185, 44);
            this.conBttn.TabIndex = 2;
            this.conBttn.Text = "Constant Data";
            this.conBttn.UseVisualStyleBackColor = true;
            this.conBttn.Click += new System.EventHandler(this.conBttn_Click);
            // 
            // strBttn
            // 
            this.strBttn.Location = new System.Drawing.Point(164, 287);
            this.strBttn.Name = "strBttn";
            this.strBttn.Size = new System.Drawing.Size(185, 44);
            this.strBttn.TabIndex = 3;
            this.strBttn.Text = "String Data";
            this.strBttn.UseVisualStyleBackColor = true;
            this.strBttn.Click += new System.EventHandler(this.strBttn_Click);
            // 
            // DataTypes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 450);
            this.Controls.Add(this.strBttn);
            this.Controls.Add(this.conBttn);
            this.Controls.Add(this.boolBttn);
            this.Controls.Add(this.numBttn);
            this.Name = "DataTypes";
            this.Text = "DataTypes";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button numBttn;
        private System.Windows.Forms.Button boolBttn;
        private System.Windows.Forms.Button conBttn;
        private System.Windows.Forms.Button strBttn;
    }
}

