﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        String function;
        double opperand1;
        double opperand2;
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void radiusCircle(object sender, RoutedEventArgs e)
        {
            double x = 0.0;
            double pi = Math.PI;
            double r = Double.Parse(screen.Text);
            x = pi * r;
            x = x * r;
            screen.Text = x.ToString();

         
        }
        
        private void backClick(object sender, RoutedEventArgs e)
        {
            if(screen.Text == "0")
            {
                screen.Text = "0";
            }
            else if(screen.Text.Length == 1)
            {
                screen.Text = "0";
            }
            else if (screen.Text.Contains("Error"))
            {
                screen.Text = "0";
            }
            else
            {
                screen.Text = screen.Text.Remove(screen.Text.Length - 1);
            }
               
        }


        private void numberClick(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            String x = button.Content.ToString();
            String y = screen.Text;
           
            if (x == ".")
            {
                if(y.Contains("e") || y.Contains("π"))
                {
                    screen.Text = y;
                }
                else if (y == "0")
                {
                    screen.Text = "0.";
                }
                else if (screen.Text.Contains("."))
                {
                    screen.Text = screen.Text;
                }
                else
                {
                    screen.Text = screen.Text + x;
                }
            }
            else if (x == "e")
            {     
               screen.Text = "e";
            }
            else if (x == "π" )
            {
                screen.Text = "π"; 
            }
            else if (y == "0" || y == "π" || y == "e" || function != null)
            {
             
                screen.Text = x;
            }
            else
            {
                String z = y + x;
                screen.Text = z;
            }

            
        }

        
        private void functionButton(object sender, RoutedEventArgs e)
        {
            string x = screen.Text;
            Button button = (Button)sender;
            if (opperand1 != 0.00)
            {
                equalButton(button, e);
                opperand1 = Double.Parse(screen.Text);
            }
            else if (x == "π")
            {
                opperand1 = Math.PI;
            }
            else if (x == "e")
            {
                opperand1 = Math.E;
            }
            else
            {
                opperand1 = Double.Parse(screen.Text);
            }
            function = button.Content.ToString();
            
        }

        private void equalButton(object sender, RoutedEventArgs e)
        {
            String x = screen.Text;
            if (x == "π")
            {
                opperand2 = Math.PI;
            }
            else if(x == "e")
            {
                opperand2 = Math.E;
            }
            else
            {
                opperand2 = Double.Parse(screen.Text);
            }
            if(function == "+")
            {
                double answer = opperand1 + opperand2;
                screen.Text = answer.ToString();
                function = "new";
                opperand2 = 0;
            }
            else if(function == "-")
            {
                double answer = opperand1 - opperand2;
                screen.Text = answer.ToString();
                function = "new";
                opperand2 = 0;
            }
            else if (function == "*")
            {
                double answer = opperand1 * opperand2;
                screen.Text = answer.ToString();
                function = "new";
                opperand2 = 0;
            }
            else if (function == "/")
            {
                if (opperand2 == 0)
                {
                    screen.Text = "Error : x / 0";
                }
                else
                {
                    double answer = opperand1 / opperand2;
                    screen.Text = answer.ToString();
                    function = "new";
                    opperand2 = 0;
                }
            }
            else if (function == "^")
            {
                double answer;
                int exp = Convert.ToInt32(opperand2);
                double opperand3 = opperand1;
                for (int i = 1; i < exp; i++) 
                {
                    opperand3 = opperand3 * opperand1;
                    
                }
                answer = opperand3;
                screen.Text = answer.ToString();
                function = "new";
                opperand2 = 0;

            }
            else
            {
                screen.Text = opperand2.ToString();
            }
            
        }

        private void negativeButton(object sender, RoutedEventArgs e)
        {
            if (screen.Text.StartsWith("-"))
            {
                screen.Text = screen.Text.TrimStart('-');
            }
            else if (screen.Text == "0" || screen.Text == "")
            {

            }
            else
            {
                screen.Text = "-" + screen.Text;
            }
        }

        private void clearButton(object sender, RoutedEventArgs e)
        {
            screen.Text = "0";
            function = null;
        }
        private void num_1_Click(object sender, RoutedEventArgs e)
        {
           
        }

        private void screen_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {

        }
    }


  
}
